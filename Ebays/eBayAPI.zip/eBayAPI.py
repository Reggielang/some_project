import urllib.request
import urllib.parse
import pymysql
import json

url = "http://open.api.ebay.com/shopping?callname=GetUserProfile&responseencoding=JSON" \
      "&appid=LuoHongL-FYP-PRD-3bd28c8f4-714274ac&siteid=0&version=967&UserID=alldayzip" \
      "&IncludeSelector=FeedbackHistory"
header = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)'
                 'Chrome/72.0.3626.121 Safari/537.36'
}
request = urllib.request.Request(url, headers=header)
reponse = urllib.request.urlopen(request).read()

fhandle = open("./1.json", "wb")
fhandle.write(reponse)
fhandle.close()




