import json
import requests
import pymysql
def my_conn(host,user,passwd,port,db):
    conn = pymysql.connect(
        host=host,
        user=user,
        passwd=passwd,
        port=port,
        db=db,
        charset='utf8',
        cursorclass = pymysql.cursors.DictCursor
    )

    return conn
def my_close(conn):
    conn.close()
def my_insert(conn,data):
    keys_sql = ','.join(data.keys())
    values_sql = []
    for v in data.values():
        # v = ''.join(v)
        values_sql.append('"%s"' % v)
    a = ','.join(values_sql)
    sql = "INSERT INTO ebayitem(%s) VALUES (%s)" % (keys_sql, a)
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
def get_data(conn,url):
    wb_data = requests.get(url=url)
    wb_data = json.loads(wb_data.text)
    # print(wb_data)
    out_data = {}
    for i in wb_data['findItemsByKeywordsResponse'][0]['searchResult'][0]['item']:
        # print(i)
        # print(i.keys())
        # exit()
        # my_insert(conn=conn,data=i)
        out_data['itemId'] = i.get('itemId')
        out_data['title'] = i.get('title')
        out_data['globalId'] = i.get('globalId')
        out_data['primaryCategory_categoryId'] = i.get('primaryCategory')[0].get('categoryId')
        out_data['viewItemURL'] = i.get('viewItemURL')
        out_data['paymentMethod'] = i.get('paymentMethod')
        out_data['location'] = i.get('location')
        out_data['country'] = i.get('country')
        out_data['sellerInfo_sellerUserName'] = i.get('sellerInfo')[0].get('sellerUserName')
        out_data['sellerInfo_feedbackScore'] = i.get('sellerInfo')[0].get('feedbackScore')
        out_data['sellerInfo_positiveFeedbackPercent'] = i.get('sellerInfo')[0].get('positiveFeedbackPercent')
        out_data['sellerInfo_feedbackRatingStar'] = i.get('sellerInfo')[0].get('feedbackRatingStar')
        out_data['sellerInfo_topRatedSeller'] = i.get('sellerInfo')[0].get('topRatedSeller')
        out_data['sellingStatus_currentPrice_currencyId'] = i.get('sellingStatus')[0].get('currentPrice')[0].get('@currencyId')
        out_data['sellingStatus_currentPrice_value'] = i.get('sellingStatus')[0].get('currentPrice')[0].get('__value__')
        out_data['sellingStatus_convertedCurrentPrice_currencyId'] = i.get('sellingStatus')[0].get('convertedCurrentPrice')[0].get('@currencyId')
        out_data['sellingStatus_convertedCurrentPrice_value'] = i.get('sellingStatus')[0].get('convertedCurrentPrice')[0].get('__value__')
        out_data['sellingStatus_sellingState'] = i.get('sellingStatus')[0].get('sellingState')
        out_data['sellingStatus_timeLeft'] = i.get('sellingStatus')[0].get('timeLeft')
        out_data['condition_conditionId'] = i.get('condition')[0].get('conditionId')
        out_data['condition_conditionDisplayName'] = i.get('condition')[0].get('conditionDisplayName')
        print(out_data)

        my_insert(conn=conn,data=out_data)
if __name__ == '__main__':
    conn = my_conn(host='127.0.0.1', user='root', passwd='123456', port=3306, db='world')

    get_data(conn=conn,url='http://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsByKeywords'
                           '&SERVICE-VERSION=1.0.0&SECURITY-APPNAME=LuoHongL-FYP-PRD-3bd28c8f4-714274ac'
                           '&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&outputSelector=SellerInfo'
                           '&keywords=iPhone XS Max'
                           '&itemFilter(0).name=ExcludeAutoPay'
                           '&itemFilter(0).name=ture'
                           '&itemFilter(1).name=MinPrice'
                           '&itemFilter(1).value=50.0&itemFilter(1).paramName=Currency&itemFilter(1).paramValue=USD')
