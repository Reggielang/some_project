#读取数据，并去除重复信息(Read the data and remove duplicate information)
import pandas as pd

data_item = pd.read_csv(r'ebayitem.csv',sep=',',encoding='ISO-8859-2')
#data_item.info()
data_item['itemId'].value_counts()
#print(data_item['itemId'].value_counts())
data_item.drop_duplicates('itemId','last',inplace=True)
data_item.info()
#取出我们关心的特征列( figure out the characteristic columns that we care about)
data_item_src = data_item.loc[:,['itemId','viewItemURL','sellerInfo_sellerUserName','condition_conditionId',
                                 'condition_conditionDisplayName','label']]
#print(data_item_src.head(1))

#读取数据，并去除重复信息(Read the data and remove duplicate information)
data_seller = pd.read_csv(r'ebayseller.csv',sep=',')
data_seller.drop_duplicates('UserID','last',inplace=True)
#取出有用的特征(Take out the useful features)
data_seller_src = data_seller.loc[:,['UserID','FeedbackRatingStar','FeedbackScore','NewUser','SellerBusinessType',
                                     'PositiveFeedbackPercent','UniqueNegativeFeedbackCount','Rating_1','RatingCount_1',
                                     'Rating_2','RatingCount_2','Rating_3','RatingCount_3','Rating_4','RatingCount_4']]

#对data_seller_src的缺失值进行填充，具体为填充众数(Fill the missing value of data_seller_src, specifically, fill mode)
features_mode = {}
for f in data_seller_src.columns:
    print (f,':', list(data_seller_src[f].dropna().mode().values))
    features_mode[f] = list(data_seller_src[f].dropna().mode().values)[0]
data_seller_src.fillna(features_mode,inplace=True)
#print(data_seller_src.isnull().any())


#合并两个数据,粗略合并(Merge two pieces of data, roughly)
data_item_src.index=range(len(data_item_src))
data_seller_src.index=range(len(data_seller_src))
data_merge = pd.concat([data_item_src,data_seller_src],axis=1)

#对合并后的数据进行精细调整(Fine-tune the merged data)
for i in range(len(data_merge)):
    try:
        index = data_item_src.loc[i,'sellerInfo_sellerUserName']
        data_merge.iloc[i,6:] = data_seller_src.loc[data_seller_src['UserID']==index].values[0,:]
    except:
        print(i,index)
        print(data_seller_src[data_seller_src['UserID']==index])
data_merge.drop(data_merge.index[22],inplace=True)     #删除没有店铺信息的数据(Delete data without store information)

# 将融合的数据保存至文件(Save the merged data to a file)
data_merge.to_csv('data_merge1.csv',index=False)

#离散数据的数字化(Digitization of discrete data)
feedbackRatingStar_mapping = { 'None':5,'Yellow':30,'Blue':75,'Turquoise':300,'Purple':750,'Red':3000,'Green':7500,
                              'YellowShooting':35000/2,'TurquoiseShooting':75000/2,'PurpleShooting':75000,'RedShooting':300000,
                             'GreenShooting':750000,'SilverShooting':1500000}
data_merge['FeedbackRatingStar'] = data_merge['FeedbackRatingStar'].map(feedbackRatingStar_mapping)

#离散数据的数字化(Digitization of discrete data)
condition_conditionDisplayName_mapping = {'Manufacturer refurbished':0,'new':2,'New':2,'Open box':4,'Seller refurbished':8,'Used':10}
data_merge['condition_conditionDisplayName'] = data_merge['condition_conditionDisplayName'] .map(condition_conditionDisplayName_mapping)

#删除对分类无用的冗余特征(Remove redundant features that are useless for classification)
data_merge.drop(labels=['itemId','sellerInfo_sellerUserName','UserID'], axis=1,inplace = True)

#将viewItemURL列暂时删除，对数据进行one-hot编码后在将其加在数据最后(Temporarily delete the viewItemURL column, one-hot encode the data and add it to the end of the data)
viewItemURL = data_merge['viewItemURL']
data_merge.drop(labels=['viewItemURL'], axis=1,inplace = True)
#对数据中定型离散型的特征进行one-hot编码(One-hot coding is carried out for the characteristics of the stereotyped discrete type in the data)
data_merge = pd.get_dummies(data_merge)
data_merge['viewItemURL']= viewItemURL    #将viewItemURL加在数据最后(Add the viewItemURL to the end of the data)

#删除对分类无用的冗余特征(Remove redundant features that are useless for classification)
data_merge.drop(labels=['NewUser'], axis=1,inplace = True)


#将label列放在最后(Put the label column in the last)
labela = data_merge['label']
data_merge.drop(labels=['label'], axis=1,inplace = True)
data_merge['label']= labela
print('++++++++++')
print(data_merge.columns)
print('++++++++++')


#将数据中0-1样本分开(Separate the 0-1 samples from the data)
data_0 = data_merge[data_merge['label']==0]
data_1 = data_merge[data_merge['label']==1]

#将dataFrame类型数据转成数组(Turn dataFrame type data into an array)
import numpy as np
data_1 = np.asarray(data_1)
data_0 = np.asarray(data_0)
np.random.shuffle(data_0)       #将data0中的数据打乱(Scramble the data in data0)
data_all = np.concatenate((data_1,data_0),axis=0)      #将数据中0-1样本合并，并把标签为1的放在数据最上面(Combine the 0-1 samples in the data and put the data labeled as 1 at the top)
print(data_all.shape)



#取出前30条数据用来训练和验证决策树模型(The first 30 pieces of data are taken out to train and verify the decision tree model)
data_x = data_all[:30,:]
data_y = data_x[:,-1]           #最后一个特征存放的是URL(The last feature is the URL)
data_x = data_x[:,:-1]
#print(data_x.shape)

#将30条数据分成训练集和验证集，其中训练集80%，验证集20%(30 pieces of data were divided into training set and verification set, of which training set was 80% and verification set was 20%)
from sklearn.model_selection import train_test_split
train_data,test_data,train_target,test_target = train_test_split(data_x,data_y,test_size=0.2,stratify=data_y)

from sklearn import tree       #导入机器学习决策树包(Import the machine learning decision tree package)
clf  = tree.DecisionTreeClassifier(criterion="entropy",random_state=3)   #分类器决策树 熵增益(The classifier decision tree entropy gain)
train_target = train_target.astype('int')                    #将训练集便签转换成int类型(Converts a training set memo to type int)
test_target = test_target.astype('int')                      #将验证集便签转换成int类型(Converts the validation set memo to an int type)

# 建立模型(Build a model)
clf.fit(train_data[:,:-1],train_target.astype('int'))        #模型的运行(Model operation)

y_pred = clf.predict(test_data[:,:-1])        #验证集预测(Validation set prediction)

for i in range(len(y_pred)):
    if y_pred[i]==1:
        print(test_data[i,-1])               #打印输出验证集中可能是诈骗商品的URL(The printout validation set may be the URL of the fraudulent item)
#通过两个参数验证模型效果好坏，overall accuracy和混淆矩阵(Overall accuracy and overall accuracy of the model were verified by two parameters)
from sklearn import metrics
print (metrics.accuracy_score(y_true = test_target,y_pred = y_pred)) #真实值和预测值  给出预测精度（overall accuracy）(The real and predicted values give the prediction accuracy)
print (metrics.confusion_matrix(y_true=test_target,y_pred = y_pred))  #打印输出混淆矩阵(Printout confusion matrix)

#将决策树模型保存(Save the decision tree model)
from sklearn.externals import joblib
joblib.dump(clf,'DT.pkl')

#加载模型，对所有数据进行预测(Load the model and predict all the data)
clf = joblib.load('DT.pkl')
ypre = clf.predict(data_all[:,:-2])

#将预测为诈骗商品的URL输出至csv文件(Export the URL predicted as a fraudulent commodity to a CSV file)
res = []
for i in range(len(ypre)):
    if int(ypre[i]) == 1:
        res.append(data_all[i,-2])
result = pd.DataFrame({'URL':res})
result.to_csv('DT_result.csv',index=False,header='URL')

import pydotplus
dot_data = tree.export_graphviz(clf, out_file=None)
graph = pydotplus.graph_from_dot_data(dot_data)
graph.write_pdf("ebays.pdf")


