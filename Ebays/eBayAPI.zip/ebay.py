import requests
from  lxml import etree
import re
import xlsxwriter
import pymysql
def get_info(conn,url):
    headers = {
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
                      '73.0.3683.75 Safari/537.36',
    }
    wb_data =requests.get(url=url,headers=headers)
    et = etree.HTML(wb_data.text)
    out_data = {}
    try:
        out_data['Product_name'] = re.sub('\\xa0','',''.join(et.xpath('//*[@class="it-ttl"]')[0].xpath('string()')))
    except:
        out_data['Product_name'] = 'None'
    out_data['Product_sell'] = ''.join(et.xpath('//*[@class="vi-txt-underline"]/text()'))
    out_data['Product_back_positive'] = ''.join(et.xpath('//*[@class="byrfdbk_modal_top"]/div[1]/div[1]/div[1]/text()'))
    out_data['Product_back_neutral'] = ''.join(et.xpath('//*[@class="byrfdbk_modal_top"]/div[2]/div[1]/div[1]/text()'))
    out_data['Product_back_negative'] =''.join(et.xpath('//*[@class="byrfdbk_modal_top"]/div[3]/div[1]/div[1]/text()'))
    out_data['maijia_url'] = ''.join(et.xpath('//*[@class="si-inner"]/div[1]/div[1]/div[1]/a/@href'))
    infos_url = et.xpath('//*[@id="desc_ifr"]/@src')
    info_wb_data = requests.get(url=''.join(infos_url),headers=headers)
    info_et = etree.HTML(info_wb_data.text)
    infos = info_et.xpath('//*[@id="itemInfo"]/div[2]/h2|//*[@id="itemInfo"]/div[3]/h2/ul/li')
    info_count = 1
    for info in infos:
        info_data = info.xpath('string()')
        if 'Conditions Explained' not in str(info_data) or 'As well as a great' not in str(info_data):
            if info_data:
                out_data['Product_text%s'%info_count] = re.sub('\\xa0','',info_data.strip())
                info_count+=1
    print(out_data)
    get_mai_info(conn=conn,data=out_data)
def get_mai_info(conn,data):
    headers = {
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
                      '73.0.3683.75 Safari/537.36',
    }
    out_data = data
    print(data['maijia_url'])
    wb_data = requests.get(url=data['maijia_url'],headers=headers)
    et = etree.HTML(wb_data.text)
    out_data['seller_name'] = ''.join(et.xpath('//*[@id="user_info"]/div[1]/span[1]/a[1]/text()'))
    out_data['Seller_satisfaction'] = ''.join(et.xpath('//*[@id="user_info"]/div[1]/span[1]/a[2]/text()'))
    out_data['seller_back_positive'] = ''.join(et.xpath('//*[@id="feedback_ratings"]/a[1]/div/span[2]/text()'))
    out_data['seller_back_neutral'] = ''.join(et.xpath('//*[@id="feedback_ratings"]/a[2]/div/span[2]/text()'))
    out_data['seller_back_negative'] = ''.join(et.xpath('//*[@id="feedback_ratings"]/a[3]/div/span[2]/text()'))
    out_data['Seller_followers'] = ''.join(et.xpath('//*[@class="follwrs"]/div[1]/span/a/text()'))
    out_data['feedback_rating_Item_as_described'] = ''.join(et.xpath('//*[@id="dsr"]/div[1]/span[6]/text()'))
    out_data['feedback_rating_Communication']= ''.join(et.xpath('//*[@id="dsr"]/div[3]/span[6]/text()'))
    out_data['feedback_rating_Dispatch_time'] = ''.join(et.xpath('//*[@id="dsr"]/div[5]/span[6]/text()'))
    out_data['feedback_rating_Postage'] = ''.join(et.xpath('//*[@id="dsr"]/div[7]/span[6]/text()'))
    print(out_data)
    # json_to_excel(data=out_data)
    my_insert(conn=conn,data=out_data)
def json_to_excel(data):
    wookbook = xlsxwriter.Workbook('data.xlsx')
    sheet = wookbook.add_worksheet('data')
    col_number = 0
    for key in data:

        sheet.write(0,col_number,key)
        sheet.write(1,col_number,data[key])
        col_number+=1
    wookbook.close()
def my_conn(host,user,passwd,port,db):
    conn = pymysql.connect(
        host=host,
        user=user,
        passwd=passwd,
        port=port,
        db=db,
        charset='utf8',
        cursorclass = pymysql.cursors.DictCursor
    )

    return conn
def my_close(conn):
    conn.close()
def my_insert(conn,data):
    keys_sql = ','.join(data.keys())
    values_sql = []
    for v in data.values():
        values_sql.append('"%s"' % v)
    a = ','.join(values_sql)
    # print(len(data.values()))
    # print(len(data.keys()))
    sql = "INSERT INTO ebay_table(%s) VALUES (%s)" % (keys_sql, a)
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
if __name__ == '__main__':
    conn = my_conn(host='127.0.0.1', user='root', passwd='123456', port=3306, db='world')

    get_info(conn=conn,url='https://www.ebay.co.uk/itm/Apple-iPhone-8-Smartphone-64GB-256GB-Unlocked-SIM-Free-Various-'
                           'Colours/302485555948?epid=238941601&hash=item466d8b4aec:m:maTIhSx5LiChqO3Hd7bJCvg')
    my_close(conn=conn)