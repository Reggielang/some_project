import requests
import xml.etree.ElementTree as ET
import re
import pymysql
def my_conn(host,user,passwd,port,db):
    conn = pymysql.connect(
        host=host,
        user=user,
        passwd=passwd,
        port=port,
        db=db,
        charset='utf8',
        cursorclass=pymysql.cursors.DictCursor
    )

    return conn
def my_close(conn):
    conn.close()
def my_insert(conn,data):
    keys_sql = ','.join(data.keys())
    values_sql = []
    for v in data.values():
        # v = ''.join(v)
        values_sql.append('"%s"' % v)
    a = ','.join(values_sql)
    sql = "INSERT INTO ebayseller(%s) VALUES (%s)" % (keys_sql, a)
    cursor = conn.cursor()
    cursor.execute(sql)
    conn.commit()
def get_xlm_to_json(conn,url):
    wb_data = requests.get(url=url)
    with  open('data.xml','w',encoding='utf-8') as f:  # 读取链接，并将xml信息写到文件(Read the link and write the XML information to the file)
        f.write(wb_data.text)
    out_data = {}
    tree = ET.parse('data.xml')  # 读取xml文件(Read the XML file)
    root = tree.getroot()
    for i in root:  # 读取User下面所有子节点的信息(Read all the child nodes under User)
        if 'User' in str(i):
            for i1 in i:
                key = re.sub('{urn:ebay:apis:eBLBaseComponents}','', str(i1.tag))
                out_data[key] = i1.text

    for i in root.iter('{urn:ebay:apis:eBLBaseComponents}UniqueNegativeFeedbackCount'):  # 获取UniqueNegativeFeedbackCount内容(Get UniqueNegativeFeedbackCount content)
        key = re.sub('{urn:ebay:apis:eBLBaseComponents}','', str(i.tag))
        out_data[key] = i.text
    for i in root.iter('{urn:ebay:apis:eBLBaseComponents}UniquePositiveFeedbackCount'):  # UniquePositiveFeedbackCount 内容(UniquePositiveFeedbackCount content)
        key = re.sub('{urn:ebay:apis:eBLBaseComponents}','', str(i.tag))
        out_data[key] = i.text
    count = 0
    for i in root:  # 获取所有AverageRatingDetails 子节点的内容(Gets the contents of all the AverageRatingDetails child nodes)
        for i1 in i:
            if 'AverageRatingDetails' in str(i1):
                count+= 1
                for i2 in i1:
                    key = re.sub('{urn:ebay:apis:eBLBaseComponents}','', str(i2.tag))
                    out_data[key+'_%s'%count] = i2.text

    print(out_data)
    my_insert(conn=conn,data=out_data)
    print(len(out_data.keys()))
if __name__ == '__main__':
    conn = my_conn(host='127.0.0.1', user='root', passwd='123456', port=3306, db='world')

    get_xlm_to_json(conn=conn,url='http://open.api.ebay.com/shopping?callname=GetUserProfile&responseencoding=json'
                                  '&appid=LuoHongL-FYP-PRD-3bd28c8f4-714274ac&siteid=0'
                                  '&version=967&UserID=cellfeee&IncludeSelector=FeedbackHistory')
    my_close(conn=conn)